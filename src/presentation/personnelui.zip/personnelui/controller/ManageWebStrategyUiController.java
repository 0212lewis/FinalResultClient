package presentation.personnelui.controller;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Vector;

import presentation.personnelui.WebSaler.ManageWebStrategy.ManageWebStrategyControllerService;
import rmi.WebSalerRemoteHelper;
import service.Strategy.ManageWebsiteStrategy.ManageWebsiteStrategyService;
import vo.ClientVO;
import vo.StrategyVO;

public class ManageWebStrategyUiController implements ManageWebStrategyControllerService{

	ManageWebsiteStrategyService strategyservice=WebSalerRemoteHelper.getInstance().getManageWebsiteStrategyService();
	Vector<Vector<String>> strategyvo;
	List<StrategyVO> volist;
	Vector<Vector<String>> change(List<StrategyVO> list) throws RemoteException {
           Vector<Vector<String>> result=new Vector<Vector<String>>();
		for(StrategyVO vo:list){
			Vector<String> vector=new Vector<String>();
			String hotelid=vo.getHotelID();
			String strategyid=vo.getStrategyID();
			String strategyname=vo.getName();
			String introduction=vo.getIntroduction();
			String begintime=vo.getBeginTime();
			String endtime=vo.getEndTime();
			String usertype=vo.getUserType();
			String type=vo.getStrategyType();
			String discount=String.valueOf(vo.getStrategy_discount());
			
			vector.add(hotelid);
			vector.addElement(strategyid);
			vector.add(strategyname); 
			vector.add(introduction);
			vector.add(begintime);
			vector.add(endtime);
			vector.add(usertype);
			vector.add(type);
			vector.add(discount);
			
			result.add(vector);
		}
		return result;
		
	}
	@Override
	public Vector<Vector<String>> getAllWebsiteStrategy() throws RemoteException {
		
		volist=strategyservice.getAllWebsiteStrategy();
		strategyvo=change(volist);
		return strategyvo;
	}

	@Override
	public boolean addStrategy(StrategyVO strategyVO) throws RemoteException {
		boolean result=false;
		result=strategyservice.addStrategy(strategyVO);
		return result;
	}

	@Override
	public boolean changeStrategy(StrategyVO strategyVO) throws RemoteException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteStrategy(String strategyID) throws RemoteException {
		// TODO Auto-generated method stub
		return false;
	}


}
