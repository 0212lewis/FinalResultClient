package presentation.personnelui.controller;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Vector;

import presentation.personnelui.WebSaler.ViewOrder.ViewOrderControllerService;
import rmi.WebSalerRemoteHelper;
import service.Order.BrowseOrder_webWorker.BrowseOrder_webWorkerService;
import vo.OrderVO;
public class ViewOrderUiController implements ViewOrderControllerService{

	BrowseOrder_webWorkerService browseorderservice=WebSalerRemoteHelper.getInstance().getBrowseOrder_webWorkerService();
	Vector<Vector<String>> ordervo;
	List<OrderVO> volist;
	@Override
	public Vector<Vector<String>> change(List<OrderVO> list) throws RemoteException {
       Vector<Vector<String>> result=new Vector<Vector<String>>();
		
		for(OrderVO vo:list){
			Vector<String> vector=new Vector<String>();
			String orderId=vo.getOrderID();
			String clientName=vo.getClientName();
			String orderTime=vo.getOrderCreatedDate();
			String orderState=vo.getOrderStatus();
			String viewdetails="";
			String operation="";
			
			vector.add(orderId);
			vector.add(clientName);
			vector.add(orderTime);
			vector.add(orderState);
			vector.add(viewdetails);
			vector.add(operation);
			result.add(vector);
		}
		return result;
	}

	@Override
	public Vector<Vector<String>> getAllUnexecutedOrders() throws RemoteException {
		volist=browseorderservice.getAllUnexecutedOrders();
		ordervo=change(volist);
		return ordervo;
	}

	@Override
	public Vector<Vector<String>> getAllAbnormalOrders() throws RemoteException {
		volist=browseorderservice.getAllAbnormalOrders();
		ordervo=change(volist);
		return ordervo;
	}

	@Override
	public boolean withdrawAbnormalOrder(String orderID) throws RemoteException {
		return false;
	}

	@Override
	public Vector<Vector<String>> getOrderVO(String orderID) throws RemoteException {
		OrderVO vo=browseorderservice.getOrderVO(orderID);
		volist.add(vo);
		ordervo=change(volist);
		return ordervo;
	}

	@Override
	public Vector<Vector<String>> getClientAbnormalOrders(String clientID) throws RemoteException {
		volist=browseorderservice.getClientAbnormalOrders(clientID);
		ordervo=change(volist);
		return ordervo;
	}

	@Override
	public Vector<Vector<String>> getAllOrders() throws RemoteException {
		volist=browseorderservice.getAllOrders();
		ordervo=change(volist);
		return ordervo;
	}

}
