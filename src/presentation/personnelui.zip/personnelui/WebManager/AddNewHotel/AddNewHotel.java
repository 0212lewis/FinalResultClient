package presentation.personnelui.WebManager.AddNewHotel;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import presentation.personnelui.BackgroundPanel;
import presentation.personnelui.WebManager.ManageClient.ManageClient;
import presentation.personnelui.WebManager.ManageHotelPersonnel.ManageHotelPersonnel;
import presentation.personnelui.WebManager.ManageWebPersonnel.ManageWebPersonnel;
import presentation.personnelui.WebManagerMainUi.MainUi;
import presentation.personnelui.controller.AddNewHotelUiController;
import runner.WebManagerRunner;
import vo.HotelVO;

import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JTextArea;

public class AddNewHotel extends JFrame {

	private JPanel contentPane;
	private AddNewHotelUiController controller;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddNewHotel frame = new AddNewHotel();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddNewHotel() {
		new WebManagerRunner();
		this.controller=new AddNewHotelUiController();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//setUndecorated(true);
		setBounds(100, 100, 1280, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Image background1=new ImageIcon("background1.jpg").getImage();
		Image background2=new ImageIcon("background2.jpg").getImage();
		JPanel backgroundPanel=new BackgroundPanel(background1);
		backgroundPanel.setBounds(0,0,1280,800);
		contentPane.add(backgroundPanel);
		backgroundPanel.setLayout(null);
		
		
		JPanel panel = new BackgroundPanel(background2);
		panel.setBounds(77, 98, 158, 153);
		backgroundPanel.add(panel);
		
		
		JLabel hotelpersonnellabel = new JLabel("�����µľƵ�");
		hotelpersonnellabel.setForeground(Color.WHITE);
		hotelpersonnellabel.setBounds(680, 15, 343, 84);
		hotelpersonnellabel.setFont(new Font("������ͤ��ϸ�ڼ���",Font.BOLD,30));
		backgroundPanel.add(hotelpersonnellabel);
		
		JButton btnNewButton_2=new JButton("����");
		btnNewButton_2.setBounds(936, 679, 165, 50);
		backgroundPanel.add(btnNewButton_2);
		
		btnNewButton_2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
				MainUi frame=new MainUi();
				frame.setVisible(true);
			}
		});
		
		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.setBounds(513, 679, 165, 50);
		backgroundPanel.add(btnNewButton_1);
		
		
		
		JButton btnNewButton = new JButton("�����µľƵ�");
		btnNewButton.setBounds(70, 631, 184, 60);
		backgroundPanel.add(btnNewButton);
		
		btnNewButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
				AddNewHotel frame=new AddNewHotel();	
				frame.setVisible(true);
			}
		});
		
		JButton button_1 = new JButton("������վӪ����Ա");
		button_1.setBounds(70, 556, 184, 60);
		backgroundPanel.add(button_1);
		
		button_1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
				ManageWebPersonnel frame=new ManageWebPersonnel();	
				frame.setVisible(true);
			}
		});
		
		JButton button = new JButton("�����Ƶ깤����Ա");
		button.setBounds(70, 481, 184, 60);
		backgroundPanel.add(button);
		
		button.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
				ManageHotelPersonnel frame=new ManageHotelPersonnel();	
				frame.setVisible(true);
			}
		});
		
		JButton button_2 = new JButton("�����ͻ���Ϣ");
		button_2.setBounds(70, 406, 184, 60);
		backgroundPanel.add(button_2);
		
		button_2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
				ManageClient frame=new ManageClient();
				frame.setVisible(true);
			}
		});
		
		JLabel welcomeLabel = new JLabel("��ӭ�㣡");
		welcomeLabel.setBounds(106, 285, 158, 84);
		welcomeLabel.setFont(new Font("������ͤ��ϸ�ڼ���",Font.BOLD,30));
		backgroundPanel.add(welcomeLabel);
		
		JLabel label = new JLabel("\u9152\u5E97\u540D\u79F0\uFF1A");
		label.setBounds(415, 87, 131, 50);
		backgroundPanel.add(label);
		
		textField = new JTextField();
		textField.setBounds(494, 99, 117, 27);
		backgroundPanel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("\u661F\u7EA7\uFF1A");
		lblNewLabel.setBounds(750, 101, 81, 21);
		backgroundPanel.add(lblNewLabel);
		
		String[] grade={"1","2","3","4","5"};
		JComboBox comboBox = new JComboBox(grade);
		comboBox.setBounds(800, 98, 81, 27);
		backgroundPanel.add(comboBox);
		
		JLabel label_1 = new JLabel("\u9152\u5E97\u7B80\u4ECB\uFF1A");
		label_1.setBounds(415, 152, 131, 50);
		backgroundPanel.add(label_1);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(494, 168, 641, 141);
		backgroundPanel.add(textArea);
		
		JLabel label_2 = new JLabel("\u9152\u5E97\u5730\u5740\uFF1A");
		label_2.setBounds(415, 340, 131, 50);
		backgroundPanel.add(label_2);
		
		JLabel label_3 = new JLabel("\u6240\u5C5E\u5546\u5708\uFF1A");
		label_3.setBounds(714, 355, 95, 21);
		backgroundPanel.add(label_3);
		
		JLabel label_4 = new JLabel("\u9152\u5E97\u8BBE\u65BD\uFF1A");
		label_4.setBounds(415, 399, 131, 50);
		backgroundPanel.add(label_4);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setBounds(494, 415, 641, 141);
		backgroundPanel.add(textArea_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(794, 352, 117, 27);
		backgroundPanel.add(textField_1);
		
		textField_4 = new JTextField("ʡ/ֱϽ�У�");
		textField_4.setBounds(494, 352, 73, 27);
		backgroundPanel.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField("��/��/����");
		textField_5.setColumns(10);
		textField_5.setBounds(602, 352, 81, 27);
		backgroundPanel.add(textField_5);
		
		textField_6 = new JTextField("��ϸ��ַ��");
		textField_6.setColumns(10);
		textField_6.setBounds(963, 352, 158, 27);
		backgroundPanel.add(textField_6);
		
		JLabel label_5 = new JLabel("\u623F\u95F4\u7C7B\u578B\uFF1A");
		label_5.setBounds(415, 571, 131, 50);
		backgroundPanel.add(label_5);
		
		JLabel label_6 = new JLabel("\u623F\u95F4\u4EF7\u683C\uFF1A");
		label_6.setBounds(415, 619, 131, 50);
		backgroundPanel.add(label_6);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(494, 583, 220, 27);
		backgroundPanel.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(494, 631, 220, 27);
		backgroundPanel.add(textField_3);


		String hotelname=textField.getText().toString();
		int hotelgrade=Integer.parseInt(comboBox.getSelectedItem().toString());
		String introduction=textArea.getText().toString();
		String province=textField_4.getText().toString();
		String city=textField_5.getText().toString();
		String cbd=textField_1.getText().toString();
		String address=textField_6.getText().toString();
		String facility=textArea_1.getText().toString();
		String roomtypeandprice=textField_2.getText().toString();
		
		HotelVO vo=new HotelVO(province,city,cbd,address,hotelname,hotelgrade,introduction,facility,roomtypeandprice);
		
		btnNewButton_1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String result=controller.addHotel(vo);
				if(result!=""){
					JOptionPane.showMessageDialog(backgroundPanel, "���ӳɹ���","���ӽ��",JOptionPane.INFORMATION_MESSAGE);
				}else{
					JOptionPane.showMessageDialog(backgroundPanel, "����ʧ��","���ӽ��",JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		
	}
}