package presentation.personnelui.WebSaler.ManageWebStrategy.MakeNewStrategy;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import presentation.personnelui.BackgroundPanel;
import presentation.personnelui.WebManagerMainUi.MainUi;
import presentation.personnelui.WebSaler.ManageWebStrategy.ManageWebStrategy;
import presentation.personnelui.controller.ManageWebStrategyUiController;
import runner.WebSalerRunner;
import vo.StrategyVO;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;

public class MakeNewStrategy extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_4;
	private JTextField textField_6;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_5;
	private ManageWebStrategyUiController controller;
	private JTextField textField_7;
	private JTextField textField_8;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MakeNewStrategy frame = new MakeNewStrategy();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MakeNewStrategy() {
		new WebSalerRunner();
		this.controller=new ManageWebStrategyUiController();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//setUndecorated(true);
		setBounds(100, 100, 1280, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Image background1=new ImageIcon("background1.jpg").getImage();
		Image background2=new ImageIcon("background2.jpg").getImage();
		JPanel backgroundPanel=new BackgroundPanel(background1);
		backgroundPanel.setBounds(0,0,1280,800);
		contentPane.add(backgroundPanel);
		backgroundPanel.setLayout(null);
		
		
		JPanel panel = new BackgroundPanel(background2);
		panel.setBounds(77, 98, 158, 153);
		backgroundPanel.add(panel);
		
		
		JLabel hotelpersonnellabel = new JLabel("�ƶ��µ���վӪ������");
		hotelpersonnellabel.setForeground(Color.WHITE);
		hotelpersonnellabel.setBounds(602, 23, 343, 84);
		hotelpersonnellabel.setFont(new Font("������ͤ��ϸ�ڼ���",Font.BOLD,30));
		backgroundPanel.add(hotelpersonnellabel);
		
		JButton btnNewButton_2=new JButton("����");
		btnNewButton_2.setBounds(936, 679, 165, 50);
		backgroundPanel.add(btnNewButton_2);
		
		btnNewButton_2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
				ManageWebStrategy frame=new ManageWebStrategy();
				frame.setVisible(true);
			}
		});
		
		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.setBounds(513, 679, 165, 50);
		backgroundPanel.add(btnNewButton_1);
		
		JButton button_2 = new JButton("�µĲ���");
		button_2.setBounds(77, 474, 184, 60);
		backgroundPanel.add(button_2);
		
		JLabel welcomeLabel = new JLabel("��ӭ�㣡");
		welcomeLabel.setBounds(106, 285, 158, 84);
		welcomeLabel.setFont(new Font("������ͤ��ϸ�ڼ���",Font.BOLD,30));
		backgroundPanel.add(welcomeLabel);
		
		JLabel label = new JLabel("�������ƣ�");
		label.setBounds(415, 111, 131, 50);
		backgroundPanel.add(label);
		
		textField = new JTextField();
		textField.setBounds(536, 122, 216, 27);
		backgroundPanel.add(textField);
		textField.setColumns(10);
		
		JLabel label_4 = new JLabel("����������Ⱥ��");
		label_4.setBounds(860, 119, 132, 34);
		backgroundPanel.add(label_4);
		textField_12 = new JTextField();
		textField_12.setColumns(10);
		textField_12.setBounds(991, 122, 216, 27);
		backgroundPanel.add(textField_12);
		
		JLabel label_1 = new JLabel("���Կ�ʼʱ�䣺");
		label_1.setBounds(415, 176, 131, 50);
		backgroundPanel.add(label_1);
		textField_10 = new JTextField();
		textField_10.setBounds(536, 188, 216, 27);
		backgroundPanel.add(textField_10);
		textField_10.setColumns(10);
		
		JLabel label_7 = new JLabel("���Խ���ʱ�䣺");
		label_7.setBounds(860, 176, 131, 50);
		backgroundPanel.add(label_7);
		textField_11 = new JTextField();
		textField_11.setColumns(10);
		textField_11.setBounds(991, 188, 216, 27);
		backgroundPanel.add(textField_11);
		
		JLabel label_9 = new JLabel("���Լ�飺");
		label_9.setBounds(415, 241, 131, 50);
		backgroundPanel.add(label_9);
		JTextArea textArea = new JTextArea();
		textArea.setBounds(536, 257, 671, 153);
		backgroundPanel.add(textArea);
		
		JLabel label_2 = new JLabel("�Ƶ��ַ��");
		label_2.setBounds(415, 402, 131, 50);
		backgroundPanel.add(label_2);
		
		JLabel lblNewLabel = new JLabel("ʡ/ֱϽ�У�");
		lblNewLabel.setBounds(415, 470, 130, 21);
		backgroundPanel.add(lblNewLabel);
		textField_4 = new JTextField("");
		textField_4.setBounds(536, 467, 109, 27);
		backgroundPanel.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel label_8 = new JLabel("��/��/����");
		label_8.setBounds(694, 470, 130, 21);
		backgroundPanel.add(label_8);
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(791, 467, 117, 27);
		backgroundPanel.add(textField_1);
		
		JLabel label_3 = new JLabel("������Ȧ");
		label_3.setBounds(954, 470, 130, 21);
		backgroundPanel.add(label_3);
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(1049, 467, 158, 27);
		backgroundPanel.add(textField_6);
		
		JLabel label_5 = new JLabel("�Ƿ���Ի�Ա���գ�");
		label_5.setBounds(415, 533, 177, 50);
		backgroundPanel.add(label_5);
		textField_2 = new JTextField("");
		textField_2.setColumns(10);
		textField_2.setBounds(575, 545, 109, 27);
		backgroundPanel.add(textField_2);
		
		JLabel label_6 = new JLabel("�������Եķ�����Ŀ��");
		label_6.setBounds(768, 533, 177, 50);
		backgroundPanel.add(label_6);
		textField_3 = new JTextField("1");
		textField_3.setColumns(10);
		textField_3.setBounds(936, 545, 109, 27);
		backgroundPanel.add(textField_3);
		
		JLabel label_10 = new JLabel("�����ۿۣ�");
		label_10.setBounds(415, 598, 90, 50);
		backgroundPanel.add(label_10);
		textField_5 = new JTextField("");
		textField_5.setColumns(10);
		textField_5.setBounds(536, 610, 109, 27);
		backgroundPanel.add(textField_5);
		
		JLabel label_11 = new JLabel("�Ƶ�id:");
		label_11.setBounds(698, 598, 90, 50);
		backgroundPanel.add(label_11);
		
		textField_7 = new JTextField("");
		textField_7.setColumns(10);
		textField_7.setBounds(760, 610, 109, 27);
		backgroundPanel.add(textField_7);
		
		JLabel label_12 = new JLabel("��ҵ��ַ��");
		label_12.setBounds(902, 598, 90, 50);
		backgroundPanel.add(label_12);
		
		textField_8 = new JTextField("");
		textField_8.setColumns(10);
		textField_8.setBounds(975, 610, 109, 27);
		backgroundPanel.add(textField_8);
		
		
		String name=textField.getText().toString();
		String usertype=textField_12.getText().toString();
		String begintime=textField_10.getText().toString();
		String endtime=textField_11.getText().toString();
		String introduction=textArea.getText().toString();
		String province=textField_4.getText().toString();
		String city=textField_1.getText().toString();
		String cbd=textField_6.getText().toString();
		String temp=textField_2.getText().toString();
		int roomnumber=Integer.parseInt(textField_3.getText().toString());
		double discount=Double.valueOf(textField_5.getText().toString());
		String hotelid=textField_7.getText().toString();
		String companyaddress=textField_8.getText().toString();
		
		
		boolean istobirthday=false;
		if(temp=="��"){
			istobirthday=true;
		}
		StrategyVO vo=new StrategyVO("",name,introduction,begintime,endtime,usertype,province,city,cbd,istobirthday,"website",hotelid,roomnumber,companyaddress,discount);
		
		btnNewButton_1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				boolean result=false;
				try {
					result=controller.addStrategy(vo);
				} catch (RemoteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(result==true){
					JOptionPane.showMessageDialog(backgroundPanel, "�����ɹ���","�������",JOptionPane.INFORMATION_MESSAGE);
					
				}else{
					JOptionPane.showMessageDialog(backgroundPanel, "����ʧ�ܣ�","�������",JOptionPane.INFORMATION_MESSAGE);
				}
			}
			
		});
	}
}
